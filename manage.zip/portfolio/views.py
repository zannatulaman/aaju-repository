from django.shortcuts import render,redirect
from django.contrib import messages
from portfolio.models import Contact,Blogs,Internship,Portfolio,About,Service

# Create your views here.
def index(request):
    return render(request,'index.html')

def about(request):
    posts=About.objects.all()
    context={"posts":posts}
    return render(request,'about.html',context)

def mywork(request):
    posts=Portfolio.objects.all()
    context={"posts":posts}
    return render(request,'mywork.html',context)

def skills(request):
    posts=Blogs.objects.all()
    context={"posts":posts}
    return render(request,'skills.html',context)
    
def contact(request):
    if request.method=="POST":
        name=request.POST.get('name')
        email=request.POST.get('email')
        subject =request.POST.get('subject')
        message=request.POST.get('message')
        query=Contact(name=name,email=email,subject=subject,message=message)
        query.save()
        messages.success(request,"Thanks for contacting us. We will get by you Soon!")

        return redirect('/')
    return render(request,'contact.html')

def basic(request):
    return render(request,'basic.html')

def internshipdetails(request):
    # if not request.user.is_authenticated:
    #     messages.warning(request,"Please login to access this page")
    #     return redirect("/auth/login/")

    if request.method=="POST":
        fname=request.POST.get('name')
        femail=request.POST.get('email')
        fusn=request.POST.get('usn')
        fcollege=request.POST.get('cname')
        foffer=request.POST.get('offer')
        fstartdate=request.POST.get('startdate')
        fenddate=request.POST.get('enddate')
        fprojreport=request.POST.get('projreport')

# converting to upper case
        fname=fname.upper()
        fusn=fusn.upper()
        fcollege=fcollege.upper()
        fprojreport=fprojreport.upper()
        foffer=foffer.upper()

        # 
        check1=Internship.objects.filter(usn=fusn)
        check2=Internship.objects.filter(email=femail)

        if check1 or check2:
            messages.warning(request,"Your Details are Stored Already")
            
        query=Internship(fullname=fname,usn=fusn,email=femail,college_name=fcollege,offer_status=foffer,start_date=fstartdate,end_date=fenddate,proj_report=fprojreport)
        query.save()

        messages.success(request,"Form is Submitted Successful!")
        return redirect('/internshipdetails/')
    return render(request,'intern.html')

def services(request):
    posts=Service.objects.all()
    context={"posts":posts}
    return render(request,'services.html',context)

